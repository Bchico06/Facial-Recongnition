# 🖼️ Nueva Funcionalidad: Ver Imágenes de Personas

## ✨ **¿Qué hace la nueva tecla 'v'?**

La tecla **'v'** (Ver) te permite visualizar todas las imágenes guardadas de una persona específica.

## 🎯 **¿Cómo funciona?**

### 1. **Presiona 'v'** en el programa principal
### 2. **Selecciona la persona** de dos formas:
   - **Por número**: Escribe 1, 2, 3, etc.
   - **Por nombre**: Escribe "Juan", "María", etc.

### 3. **El sistema busca** automáticamente en:
   - 📁 `baby_faces/` - Imágenes de referencia
   - 📁 `unknown_faces/` - Imágenes guardadas automáticamente

### 4. **Muestra cada imagen** una por una con:
   - ✅ Nombre de la persona
   - ✅ Número de imagen (1/3, 2/3, etc.)
   - ✅ Nombre del archivo
   - ✅ Instrucciones de navegación

## 🎮 **Controles durante la visualización:**

| Tecla | Acción |
|-------|--------|
| **Cualquier tecla** | Siguiente imagen |
| **'q'** | Salir de la visualización |

## 📸 **Ejemplo de uso:**

```
1. Ejecutar programa
2. Presionar 'v'
3. Ver lista: "1. Juan, 2. María, 3. Pedro"
4. Escribir "2" o "María"
5. Ver imágenes de María una por una
6. Presionar teclas para navegar
7. Presionar 'q' para volver al programa
```

## 🔍 **¿Qué busca el sistema?**

El sistema encuentra imágenes que contengan el nombre de la persona en el archivo:

### ✅ **Encontrará:**
- `Juan.jpg` → Para persona "Juan"
- `juan_1234.jpg` → Para persona "Juan"  
- `JUAN_foto.png` → Para persona "Juan"
- `familia_juan.jpeg` → Para persona "Juan"

### ❌ **NO encontrará:**
- `foto.jpg` → No contiene el nombre
- `pedro.jpg` → Para persona "Juan"

## 🎯 **Casos de uso prácticos:**

### **📷 Revisar fotos de una persona**
```
Quieres ver todas las fotos que tienes de tu hijo →
Presionas 'v' → Seleccionas "Juan" →
Ves todas sus fotos guardadas
```

### **🔍 Verificar calidad de reconocimiento**
```
El sistema no reconoce bien a alguien →
Usas 'v' para ver qué fotos tiene →
Decides si necesitas agregar más fotos
```

### **📂 Organizar tu colección**
```
Tienes muchas personas registradas →
Usas 'v' para revisar qué fotos tienes de cada una →
Identificas quién necesita más fotos
```

### **🎉 Mostrar a otros**
```
Quieres mostrar a alguien las fotos que tienes →
Usas 'v' para hacer una presentación →
Navegas por las fotos de cada persona
```

## 💡 **Consejos útiles:**

### **🏷️ Nombra bien tus archivos**
- Incluye el nombre de la persona en el archivo
- Ejemplos: `juan_cumpleanos.jpg`, `maria_vacaciones.png`

### **📁 Organiza tus carpetas**
- Usa `baby_faces/` para fotos de referencia de alta calidad
- El sistema guarda automáticamente en `unknown_faces/`

### **🔢 Usa números para rapidez**
- En lugar de escribir "Juan", escribe "1"
- Más rápido para personas con nombres largos

### **🎯 Verificación de personas**
- Si el reconocimiento falla, usa 'v' para ver qué fotos tienes
- Puede que necesites fotos con mejor iluminación

## 🚀 **Flujo completo de trabajo:**

```
1. 📸 Cargar fotos con 'c'
2. 👤 Registrar personas nuevas  
3. 🎯 Probar reconocimiento automático
4. 🔍 Si hay problemas, usar 'v' para revisar fotos
5. 📷 Agregar más fotos si es necesario
6. ✅ Sistema optimizado y funcionando
```

## 📊 **Información mostrada:**

En cada imagen verás:
- **Título**: "Juan - Imagen 2/5"
- **Archivo**: "juan_1234.jpg"  
- **Instrucción**: "Presiona cualquier tecla para continuar"
- **Navegación**: Presiona 'q' para salir

¡Ahora puedes gestionar y revisar completamente tu base de datos de personas de manera visual! 🎉📸
