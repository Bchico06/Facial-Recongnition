import cv2
import numpy as np
import os
from tkinter import Tk, filedialog, simpledialog
import pickle
import time

# Función para extraer características de una cara usando histograma
def extraer_caracteristicas(imagen_cara):
    """Extrae características de una cara usando histograma HSV"""
    try:
        # Redimensionar la cara a un tamaño estándar
        cara_redimensionada = cv2.resize(imagen_cara, (100, 100))
        
        # Convertir a HSV para mejor representación del color
        hsv = cv2.cvtColor(cara_redimensionada, cv2.COLOR_BGR2HSV)
        
        # Calcular histograma
        hist = cv2.calcHist([hsv], [0, 1, 2], None, [50, 60, 60], [0, 180, 0, 256, 0, 256])
        
        # Normalizar el histograma
        cv2.normalize(hist, hist)
        
        return hist.flatten()
    except:
        return None

# Función para comparar características
def comparar_caras(caracteristicas1, caracteristicas2):
    """Compara dos conjuntos de características usando correlación"""
    try:
        # Usar correlación para comparar histogramas
        correlacion = cv2.compareHist(caracteristicas1.reshape(-1, 1), 
                                    caracteristicas2.reshape(-1, 1), 
                                    cv2.HISTCMP_CORREL)
        return correlacion
    except:
        return 0

# Inicializar el detector de caras de OpenCV
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Verificar que el clasificador se cargó correctamente
if face_cascade.empty():
    print("Error: No se pudo cargar el clasificador de caras.")
    print("Intentando ruta alternativa...")
    
    # Intentar ruta alternativa
    try:
        face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
        if face_cascade.empty():
            print("Error: No se encuentra el archivo haarcascade_frontalface_default.xml")
            exit(1)
    except:
        print("Error crítico: No se puede inicializar el detector de caras.")
        exit(1)
else:
    print("Clasificador de caras cargado correctamente.")

# Función para seleccionar imágenes de bebés
def cargar_imagen():
    root = Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(title="Selecciona una imagen de bebé", filetypes=[("Imágenes", "*.jpg;*.png;*.jpeg")])
    return file_path

# Ruta a las imágenes de bebés conocidos y desconocidos
KNOWN_FACES_DIR = "baby_faces"
UNKNOWN_FACES_DIR = "unknown_faces"
FEATURES_FILE = "face_features.pkl"

# Variables globales para el sistema de corrección
modo_correccion = False
cara_a_corregir = None
caracteristicas_a_corregir = None
posicion_cara_correccion = None

os.makedirs(KNOWN_FACES_DIR, exist_ok=True)
os.makedirs(UNKNOWN_FACES_DIR, exist_ok=True)

# Función para guardar características
def guardar_caracteristicas():
    try:
        with open(FEATURES_FILE, 'wb') as f:
            pickle.dump({
                'features': known_face_features,
                'names': known_face_names
            }, f)
        print("Características guardadas correctamente.")
    except Exception as e:
        print(f"Error al guardar características: {e}")

# Función para mostrar estadísticas
def mostrar_estadisticas():
    print("\n📊 ESTADÍSTICAS DE LA BASE DE DATOS:")
    print(f"   👥 Total de personas registradas: {len(known_face_names)}")
    if known_face_names:
        print("   📋 Personas conocidas:")
        for i, nombre in enumerate(known_face_names):
            print(f"      {i+1}. {nombre}")
    print("-" * 50)

# Función para mostrar estadísticas
def mostrar_estadisticas():
    print("\n📊 ESTADÍSTICAS DE LA BASE DE DATOS:")
    print(f"   👥 Total de personas registradas: {len(known_face_names)}")
    if known_face_names:
        print("   📋 Personas conocidas:")
        for i, nombre in enumerate(known_face_names):
            print(f"      {i+1}. {nombre}")
    print("-" * 50)

# Función para ver imágenes de una persona específica
def ver_imagenes_persona():
    if not known_face_names:
        print("❌ No hay personas registradas en la base de datos.")
        return
    
    print("\n👥 PERSONAS DISPONIBLES:")
    for i, nombre in enumerate(known_face_names):
        print(f"   {i+1}. {nombre}")
    
    try:
        root = Tk()
        root.withdraw()
        seleccion = simpledialog.askstring("Ver Imágenes", 
            f"¿De qué persona quieres ver las imágenes?\n\nEscribe el nombre exacto o el número (1-{len(known_face_names)}):")
        
        if not seleccion:
            print("⏭️ Operación cancelada.")
            return
        
        # Determinar si es un número o un nombre
        persona_seleccionada = None
        if seleccion.isdigit():
            num = int(seleccion)
            if 1 <= num <= len(known_face_names):
                persona_seleccionada = known_face_names[num - 1]
            else:
                print(f"❌ Número fuera de rango. Debe ser entre 1 y {len(known_face_names)}")
                return
        else:
            # Buscar por nombre (case insensitive)
            for nombre in known_face_names:
                if nombre.lower() == seleccion.lower():
                    persona_seleccionada = nombre
                    break
            
            if not persona_seleccionada:
                print(f"❌ No se encontró a '{seleccion}' en la base de datos.")
                return
        
        print(f"\n🔍 Buscando imágenes de: {persona_seleccionada}")
        
        # Buscar imágenes en ambas carpetas
        imagenes_encontradas = []
        
        # Buscar en carpeta de imágenes conocidas
        if os.path.exists(KNOWN_FACES_DIR):
            for filename in os.listdir(KNOWN_FACES_DIR):
                if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
                    # Verificar si el nombre de archivo contiene el nombre de la persona
                    nombre_archivo = os.path.splitext(filename)[0].lower()
                    if persona_seleccionada.lower() in nombre_archivo:
                        imagenes_encontradas.append(os.path.join(KNOWN_FACES_DIR, filename))
        
        # Buscar en carpeta de imágenes guardadas
        if os.path.exists(UNKNOWN_FACES_DIR):
            for filename in os.listdir(UNKNOWN_FACES_DIR):
                if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
                    # Verificar si el nombre de archivo contiene el nombre de la persona
                    if persona_seleccionada.lower() in filename.lower():
                        imagenes_encontradas.append(os.path.join(UNKNOWN_FACES_DIR, filename))
        
        if not imagenes_encontradas:
            print(f"❌ No se encontraron imágenes de {persona_seleccionada}")
            print("💡 Las imágenes se buscan por nombre de archivo que contenga el nombre de la persona.")
            return
        
        print(f"✅ Encontradas {len(imagenes_encontradas)} imagen(es) de {persona_seleccionada}")
        
        # Mostrar cada imagen
        for i, img_path in enumerate(imagenes_encontradas):
            print(f"📸 Mostrando imagen {i+1}/{len(imagenes_encontradas)}: {os.path.basename(img_path)}")
            
            image = cv2.imread(img_path)
            if image is not None:
                # Redimensionar si es muy grande
                height, width = image.shape[:2]
                if width > 600 or height > 600:
                    scale = min(600/width, 600/height)
                    new_width = int(width * scale)
                    new_height = int(height * scale)
                    image_display = cv2.resize(image, (new_width, new_height))
                else:
                    image_display = image.copy()
                
                # Agregar información en la imagen
                cv2.putText(image_display, f"{persona_seleccionada} - Imagen {i+1}/{len(imagenes_encontradas)}", 
                          (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                cv2.putText(image_display, f"Archivo: {os.path.basename(img_path)}", 
                          (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
                cv2.putText(image_display, "Presiona cualquier tecla para continuar", 
                          (10, image_display.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 1)
                
                # Mostrar la imagen
                cv2.imshow(f"Imágenes de {persona_seleccionada}", image_display)
                key = cv2.waitKey(0)  # Esperar a que se presione una tecla
                
                # Si presiona 'q', salir del bucle
                if key & 0xFF == ord('q'):
                    print("⏹️ Visualización interrumpida por el usuario.")
                    break
            else:
                print(f"❌ Error al cargar {img_path}")
        
        cv2.destroyAllWindows()
        print(f"✅ Visualización completada para {persona_seleccionada}")
        
    except ValueError:
        print("❌ Entrada inválida. Debes escribir un número o un nombre.")
    except Exception as e:
        print(f"❌ Error: {e}")

# Función para iniciar el modo de corrección
def iniciar_modo_correccion(cara_detectada, caracteristicas, posicion):
    """Inicia el modo corrección para una cara específica"""
    global modo_correccion, cara_a_corregir, caracteristicas_a_corregir, posicion_cara_correccion
    
    modo_correccion = True
    cara_a_corregir = cara_detectada.copy()
    caracteristicas_a_corregir = caracteristicas.copy()
    posicion_cara_correccion = posicion
    
    print("\n" + "="*50)
    print("MODO CORRECCIÓN ACTIVADO")
    print("="*50)
    print("La cara ha sido marcada para corrección.")
    print("Presiona 'r' para confirmar la corrección")
    print("Presiona 'x' para cancelar")
    print("="*50)

# Función para corregir reconocimiento erróneo
def corregir_reconocimiento():
    """Permite corregir un reconocimiento erróneo"""
    global modo_correccion, cara_a_corregir, caracteristicas_a_corregir, posicion_cara_correccion
    global known_face_features, known_face_names
    
    if not modo_correccion:
        print("No hay ninguna corrección pendiente.")
        return
    
    print("\n" + "="*50)
    print("CORRIGIENDO RECONOCIMIENTO")
    print("="*50)
    
    # Mostrar lista de personas conocidas
    if known_face_names:
        print("Personas registradas:")
        for i, nombre in enumerate(known_face_names, 1):
            print(f"{i}. {nombre}")
        print(f"{len(known_face_names) + 1}. Persona nueva")
    else:
        print("No hay personas registradas aún.")
        print("1. Persona nueva")
    
    try:
        from tkinter import Tk, simpledialog
        root = Tk()
        root.withdraw()
        
        # Crear lista de opciones
        opciones = known_face_names.copy()
        opciones.append("Persona nueva")
        
        # Mostrar opciones
        mensaje = "Selecciona la persona correcta:\n\n"
        for i, opcion in enumerate(opciones, 1):
            mensaje += f"{i}. {opcion}\n"
        
        seleccion = simpledialog.askstring("Corrección de Reconocimiento", 
                                          mensaje + "\nIngresa el número de la opción:")
        
        if not seleccion or not seleccion.strip():
            print("Corrección cancelada.")
            cancelar_correccion()
            return
        
        opcion = int(seleccion.strip())
        
        if 1 <= opcion <= len(known_face_names):
            # Persona existente seleccionada
            nombre_correcto = known_face_names[opcion - 1]
            print(f"Corrigiendo a: {nombre_correcto}")
            
            # Actualizar las características promediándolas
            indice_persona = opcion - 1
            known_face_features[indice_persona] = (known_face_features[indice_persona] + caracteristicas_a_corregir) / 2
            
            # Guardar la imagen con el nombre correcto
            import time
            timestamp = int(time.time())
            filename = f"{nombre_correcto}_{timestamp}.jpg"
            filepath = os.path.join(UNKNOWN_FACES_DIR, filename)
            cv2.imwrite(filepath, cara_a_corregir)
            
            print(f"✓ Imagen guardada como: {filename}")
            print(f"✓ Características actualizadas para {nombre_correcto}")
            
        elif opcion == len(known_face_names) + 1:
            # Persona nueva
            nombre_correcto = simpledialog.askstring("Nueva Persona", 
                                                    "Ingresa el nombre de la nueva persona:")
            if nombre_correcto and nombre_correcto.strip():
                nombre_correcto = nombre_correcto.strip()
                
                # Verificar que el nombre no exista ya
                if nombre_correcto.lower() not in [n.lower() for n in known_face_names]:
                    # Agregar nueva persona
                    known_face_features.append(caracteristicas_a_corregir)
                    known_face_names.append(nombre_correcto)
                    
                    # Guardar la imagen
                    timestamp = int(time.time())
                    filename = f"{nombre_correcto}_{timestamp}.jpg"
                    filepath = os.path.join(UNKNOWN_FACES_DIR, filename)
                    cv2.imwrite(filepath, cara_a_corregir)
                    
                    print(f"✓ Nueva persona '{nombre_correcto}' registrada")
                    print(f"✓ Imagen guardada como: {filename}")
                else:
                    print(f"⚠️ El nombre '{nombre_correcto}' ya existe en la base de datos.")
                    # Buscar la persona existente y actualizar características
                    indice_existente = [n.lower() for n in known_face_names].index(nombre_correcto.lower())
                    known_face_features[indice_existente] = (known_face_features[indice_existente] + caracteristicas_a_corregir) / 2
                    print(f"✓ Características actualizadas para {known_face_names[indice_existente]} existente")
            else:
                print("Nombre inválido. Corrección cancelada.")
                cancelar_correccion()
                return
        else:
            print("Opción inválida. Corrección cancelada.")
            cancelar_correccion()
            return
        
        # Guardar la base de datos actualizada
        guardar_caracteristicas()
        print("✓ Base de datos actualizada")
        print("✓ El sistema aprenderá de esta corrección")
        
    except ValueError:
        print("Entrada inválida. Corrección cancelada.")
        cancelar_correccion()
        return
    except Exception as e:
        print(f"Error durante la corrección: {e}")
        cancelar_correccion()
        return
    
    # Finalizar modo corrección
    cancelar_correccion()

def cancelar_correccion():
    """Cancela el modo corrección"""
    global modo_correccion, cara_a_corregir, caracteristicas_a_corregir, posicion_cara_correccion
    
    modo_correccion = False
    cara_a_corregir = None
    caracteristicas_a_corregir = None
    posicion_cara_correccion = None
    print("Modo corrección desactivado.")

# Cargar características y nombres guardados
known_face_features = []
known_face_names = []

# Intentar cargar características guardadas
try:
    with open(FEATURES_FILE, 'rb') as f:
        data = pickle.load(f)
        known_face_features = data['features']
        known_face_names = data['names']
    print(f"Cargadas {len(known_face_names)} caras conocidas desde archivo.")
except:
    print("No se encontró archivo de características previo. Cargando desde imágenes...")

# Si no hay características guardadas, cargar desde imágenes
if not known_face_features and os.path.exists(KNOWN_FACES_DIR):
    print("🔍 Escaneando carpeta de imágenes conocidas...")
    imagenes_procesadas = 0
    for filename in os.listdir(KNOWN_FACES_DIR):
        if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
            img_path = os.path.join(KNOWN_FACES_DIR, filename)
            print(f"   Procesando: {filename}")
            image = cv2.imread(img_path)
            if image is not None:
                # Detectar caras en la imagen
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                faces = face_cascade.detectMultiScale(gray, 1.1, 4)
                
                if len(faces) > 0:
                    x, y, w, h = faces[0]  # Tomar la primera cara
                    cara = image[y:y+h, x:x+w]
                    caracteristicas = extraer_caracteristicas(cara)
                    if caracteristicas is not None:
                        known_face_features.append(caracteristicas)
                        nombre = os.path.splitext(filename)[0]
                        known_face_names.append(nombre)
                        print(f"   ✅ {nombre} agregado a la base de datos")
                        imagenes_procesadas += 1
                    else:
                        print(f"   ❌ No se pudieron extraer características de {filename}")
                else:
                    print(f"   ❌ No se detectaron caras en {filename}")
            else:
                print(f"   ❌ Error al cargar {filename}")
    
    if imagenes_procesadas > 0:
        guardar_caracteristicas()
        print(f"🎉 {imagenes_procesadas} persona(s) cargada(s) desde imágenes")
    else:
        print("📂 No se encontraron imágenes válidas en la carpeta baby_faces/")

# Función para guardar características
def guardar_caracteristicas():
    try:
        with open(FEATURES_FILE, 'wb') as f:
            pickle.dump({
                'features': known_face_features,
                'names': known_face_names
            }, f)
        print("Características guardadas correctamente.")
    except Exception as e:
        print(f"Error al guardar características: {e}")

# Función para mostrar estadísticas
def mostrar_estadisticas():
    print("\n📊 ESTADÍSTICAS DE LA BASE DE DATOS:")
    print(f"   👥 Total de personas registradas: {len(known_face_names)}")
    if known_face_names:
        print("   📋 Personas conocidas:")
        for i, nombre in enumerate(known_face_names):
            print(f"      {i+1}. {nombre}")
    print("-" * 50)

# Inicializar la captura de video
print("Inicializando cámara...")
video_capture = cv2.VideoCapture(0)  # Puedes usar un archivo: cv2.VideoCapture("video.mp4")

# Verificar si la cámara se abrió correctamente
if not video_capture.isOpened():
    print("Error: No se pudo acceder a la cámara.")
    print("Intentando con diferentes índices de cámara...")
    
    # Intentar con otros índices de cámara
    for i in range(1, 5):
        print(f"Probando cámara en índice {i}...")
        video_capture = cv2.VideoCapture(i)
        if video_capture.isOpened():
            print(f"Cámara encontrada en índice {i}")
            break
        video_capture.release()
    
    if not video_capture.isOpened():
        print("No se pudo encontrar ninguna cámara.")
        print("Iniciando en modo de procesamiento de imágenes...")
        
        # Crear una imagen de demostración
        demo_frame = np.zeros((480, 640, 3), dtype=np.uint8)
        cv2.putText(demo_frame, "No hay camara disponible", (50, 150), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        cv2.putText(demo_frame, "CONTROLES:", (50, 200), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
        cv2.putText(demo_frame, "'c' - Cargar y ver imagen", (70, 230), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        cv2.putText(demo_frame, "'v' - Ver imagenes persona", (70, 260), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        cv2.putText(demo_frame, "'r' - Corregir reconocimiento", (70, 290), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        cv2.putText(demo_frame, "'i' - Ver base de datos", (70, 320), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        cv2.putText(demo_frame, "'s' - Guardar", (70, 350), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        cv2.putText(demo_frame, "'q' - Salir", (70, 380), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
        
        # Mostrar estadísticas en pantalla
        if known_face_names:
            cv2.putText(demo_frame, f"Personas registradas: {len(known_face_names)}", (50, 440), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 1)
        else:
            cv2.putText(demo_frame, "No hay personas registradas", (50, 440), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 1)
        
        # Modo sin cámara
        usar_camara = False
else:
    print("Cámara inicializada correctamente.")
    # Configurar resolución de la cámara para mejor rendimiento
    video_capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    video_capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    usar_camara = True

print("Sistema de reconocimiento facial iniciado.")
print("📋 CONTROLES DISPONIBLES:")
print("   'c' - Cargar imagen y agregar personas visualmente")
print("   'v' - Ver imágenes de una persona específica")
print("   'r' - Corregir reconocimiento erróneo (entrenar sistema)")
print("   's' - Guardar características manualmente")
print("   'i' - Mostrar información de la base de datos")  
print("   'q' - Salir del programa")
print("-" * 50)

# Mostrar estadísticas iniciales
mostrar_estadisticas()

while True:
    if usar_camara:
        ret, frame = video_capture.read()
        if not ret:
            print("Error: No se pudo leer el frame de la cámara.")
            print("Reintentando...")
            continue
    else:
        # Usar imagen de demostración cuando no hay cámara
        frame = demo_frame.copy()

    # Convertir a escala de grises para detección
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Detectar caras
    faces = face_cascade.detectMultiScale(gray, 1.1, 4)
    
    # Debug: mostrar número de caras detectadas
    if len(faces) > 0:
        print(f"Detectadas {len(faces)} cara(s)")
    
    for (x, y, w, h) in faces:
        # Extraer la cara
        cara = frame[y:y+h, x:x+w]
        caracteristicas_cara = extraer_caracteristicas(cara)
        
        name = "Desconocido"
        mejor_coincidencia = 0
        umbral_reconocimiento = 0.6  # Ajustar según necesidad
        
        if caracteristicas_cara is not None and known_face_features:
            # Comparar con caras conocidas
            for i, caracteristicas_conocidas in enumerate(known_face_features):
                similitud = comparar_caras(caracteristicas_cara, caracteristicas_conocidas)
                
                if similitud > mejor_coincidencia and similitud > umbral_reconocimiento:
                    mejor_coincidencia = similitud
                    name = known_face_names[i]
            
            # Mostrar mensaje de reconocimiento automático
            if name != "Desconocido":
                print(f"🎯 Reconocido automáticamente: {name} (confianza: {mejor_coincidencia:.2f})")
        
        # Si no se reconoce la cara con alta confianza, verificar con umbral más bajo
        if name == "Desconocido" and caracteristicas_cara is not None:
            # Buscar similitudes con umbral más bajo para sugerir personas
            mejor_candidato = None
            mejor_similitud_baja = 0
            indice_candidato = -1
            
            for i, caracteristicas_conocidas in enumerate(known_face_features):
                similitud_baja = comparar_caras(caracteristicas_cara, caracteristicas_conocidas)
                if similitud_baja > mejor_similitud_baja and similitud_baja > 0.3:  # Umbral más bajo
                    mejor_similitud_baja = similitud_baja
                    mejor_candidato = known_face_names[i]
                    indice_candidato = i
            
            # Si encontramos un candidato similar, preguntar si es esa persona
            if mejor_candidato and mejor_similitud_baja > 0.4:
                print(f"💭 Cara similar encontrada: {mejor_candidato} (similitud: {mejor_similitud_baja:.2f})")
                
                # Usar diálogo gráfico para preguntar
                root = Tk()
                root.withdraw()
                respuesta = simpledialog.askstring("Confirmar Identidad", 
                    f"He detectado una cara similar a '{mejor_candidato}'\n(Similitud: {mejor_similitud_baja:.2f})\n\n¿Es esta persona {mejor_candidato}?\n\nEscribe 'si' para confirmar o 'no' para indicar que es otra persona:")
                
                if respuesta and respuesta.lower() in ['si', 'sí', 's', 'yes', 'y']:
                    name = mejor_candidato
                    # Actualizar características promediando con las existentes
                    known_face_features[indice_candidato] = (known_face_features[indice_candidato] + caracteristicas_cara) / 2
                    print(f"✅ Confirmado como {name}. Características actualizadas.")
                    guardar_caracteristicas()
                elif respuesta and respuesta.lower() in ['no', 'n']:
                    # Es una persona diferente, pedir nuevo nombre
                    nuevo_nombre = simpledialog.askstring("Nueva Persona", 
                        f"Esta persona NO es {mejor_candidato}.\n¿Cuál es el nombre correcto de esta persona?")
                    
                    if nuevo_nombre and nuevo_nombre.strip():
                        nuevo_nombre = nuevo_nombre.strip()
                        
                        # Verificar que el nombre no exista ya
                        if nuevo_nombre.lower() not in [n.lower() for n in known_face_names]:
                            name = nuevo_nombre
                            known_face_features.append(caracteristicas_cara)
                            known_face_names.append(name)
                            
                            # Guardar la imagen del rostro con timestamp
                            timestamp = int(time.time())
                            file_path = os.path.join(UNKNOWN_FACES_DIR, f"{name}_{timestamp}.jpg")
                            cv2.imwrite(file_path, cara)
                            print(f"✅ Nueva persona '{name}' registrada y guardada como {file_path}")
                            
                            # Guardar características automáticamente
                            guardar_caracteristicas()
                            print(f"💾 Base de datos actualizada. Total de personas: {len(known_face_names)}")
                        else:
                            print(f"⚠️ El nombre '{nuevo_nombre}' ya existe en la base de datos.")
                            name = "Desconocido"
                    else:
                        name = "Sin_Nombre"
                else:
                    # Usuario canceló o respuesta inválida
                    name = "Desconocido"
            else:
                # No hay candidatos similares, es una persona completamente nueva
                root = Tk()
                root.withdraw()
                nuevo_nombre = simpledialog.askstring("Nueva Persona Detectada", 
                    "Esta es la primera vez que veo esta cara.\n¿Cuál es el nombre de esta persona?")
                
                if nuevo_nombre and nuevo_nombre.strip():
                    nuevo_nombre = nuevo_nombre.strip()
                    
                    # Verificar que el nombre no exista ya
                    if nuevo_nombre.lower() not in [n.lower() for n in known_face_names]:
                        name = nuevo_nombre
                        known_face_features.append(caracteristicas_cara)
                        known_face_names.append(name)
                        
                        # Guardar la imagen del rostro con timestamp
                        timestamp = int(time.time())
                        file_path = os.path.join(UNKNOWN_FACES_DIR, f"{name}_{timestamp}.jpg")
                        cv2.imwrite(file_path, cara)
                        print(f"✅ Nueva persona '{name}' registrada y guardada como {file_path}")
                        
                        # Guardar características automáticamente
                        guardar_caracteristicas()
                        print(f"💾 Base de datos actualizada. Total de personas: {len(known_face_names)}")
                    else:
                        print(f"⚠️ El nombre '{nuevo_nombre}' ya existe en la base de datos.")
                        # Buscar la persona existente y actualizar características
                        indice_existente = [n.lower() for n in known_face_names].index(nuevo_nombre.lower())
                        name = known_face_names[indice_existente]
                        known_face_features[indice_existente] = (known_face_features[indice_existente] + caracteristicas_cara) / 2
                        print(f"✅ Características actualizadas para {name} existente.")
                        guardar_caracteristicas()
                else:
                    name = "Sin_Nombre"

        # Dibujar rectángulo y nombre
        color = (0, 255, 0) if name != "Desconocido" else (0, 0, 255)
        
        # Si estamos en modo corrección y esta es la cara a corregir
        if modo_correccion and posicion_cara_correccion == (x, y, w, h):
            color = (0, 255, 255)  # Amarillo para cara marcada para corrección
            cv2.rectangle(frame, (x-5, y-5), (x+w+5, y+h+5), color, 3)
        
        cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
        cv2.rectangle(frame, (x, y-35), (x+w, y), color, cv2.FILLED)
        
        # Mostrar nivel de confianza si no es desconocido
        texto = f"{name} ({mejor_coincidencia:.2f})" if name != "Desconocido" else name
        cv2.putText(frame, texto, (x + 6, y - 6), cv2.FONT_HERSHEY_DUPLEX, 0.6, (255, 255, 255), 1)
        
        # Si estamos en modo corrección, mostrar indicador
        if modo_correccion and posicion_cara_correccion == (x, y, w, h):
            cv2.putText(frame, "MARCADO PARA CORRECCION", (x, y+h+20), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 255), 1)

    # Mostrar indicador de modo corrección
    if modo_correccion:
        cv2.rectangle(frame, (10, 10), (frame.shape[1] - 10, 60), (0, 165, 255), 2)
        cv2.rectangle(frame, (10, 10), (frame.shape[1] - 10, 60), (0, 165, 255), -1)
        cv2.putText(frame, "MODO CORRECCION ACTIVO", (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(frame, "Presiona 'r' para confirmar o 'x' para cancelar", (20, 55), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

    # Mostrar la imagen
    cv2.imshow("Reconocimiento Facial - OpenCV", frame)
    
    # Controles del teclado
    key = cv2.waitKey(1) & 0xFF
    
    # Verificar si la ventana fue cerrada
    if cv2.getWindowProperty("Reconocimiento Facial - OpenCV", cv2.WND_PROP_VISIBLE) < 1:
        print("Ventana cerrada por el usuario.")
        break
    
    # Presionar 'c' para cargar una nueva imagen
    
    if key == ord('c'):
        nueva_imagen = cargar_imagen()
        if nueva_imagen:
            image = cv2.imread(nueva_imagen)
            if image is not None:
                # Mostrar la imagen cargada
                print(f"📸 Imagen cargada: {os.path.basename(nueva_imagen)}")
                
                # Redimensionar imagen para visualización si es muy grande
                height, width = image.shape[:2]
                if width > 800 or height > 600:
                    scale = min(800/width, 600/height)
                    new_width = int(width * scale)
                    new_height = int(height * scale)
                    image_display = cv2.resize(image, (new_width, new_height))
                else:
                    image_display = image.copy()
                
                # Detectar cara en la nueva imagen
                gray_nueva = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                faces_nueva = face_cascade.detectMultiScale(gray_nueva, 1.1, 4)
                
                if len(faces_nueva) > 0:
                    print(f"✅ Detectadas {len(faces_nueva)} cara(s) en la imagen")
                    
                    # Procesar cada cara detectada
                    for i, (x, y, w, h) in enumerate(faces_nueva):
                        cara_nueva = image[y:y+h, x:x+w]
                        caracteristicas_nueva = extraer_caracteristicas(cara_nueva)
                        
                        if caracteristicas_nueva is not None:
                            # Dibujar rectángulo alrededor de la cara en la imagen de visualización
                            scale_x = image_display.shape[1] / image.shape[1] if image_display.shape[1] != image.shape[1] else 1
                            scale_y = image_display.shape[0] / image.shape[0] if image_display.shape[0] != image.shape[0] else 1
                            
                            x_display = int(x * scale_x)
                            y_display = int(y * scale_y)
                            w_display = int(w * scale_x)
                            h_display = int(h * scale_y)
                            
                            # Buscar si ya existe esta cara
                            nombre_existente = None
                            mejor_similitud = 0
                            
                            if known_face_features:
                                for j, caracteristicas_conocidas in enumerate(known_face_features):
                                    similitud = comparar_caras(caracteristicas_nueva, caracteristicas_conocidas)
                                    if similitud > mejor_similitud and similitud > 0.6:
                                        mejor_similitud = similitud
                                        nombre_existente = known_face_names[j]
                            
                            if nombre_existente:
                                # Cara ya conocida
                                cv2.rectangle(image_display, (x_display, y_display), (x_display+w_display, y_display+h_display), (0, 255, 0), 2)
                                cv2.putText(image_display, f"{nombre_existente} ({mejor_similitud:.2f})", 
                                          (x_display, y_display-10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                                print(f"🎯 Cara {i+1}: Reconocida como {nombre_existente} (confianza: {mejor_similitud:.2f})")
                            else:
                                # Cara nueva - dibujar en rojo
                                cv2.rectangle(image_display, (x_display, y_display), (x_display+w_display, y_display+h_display), (0, 0, 255), 2)
                                cv2.putText(image_display, f"Cara {i+1} - Nueva", 
                                          (x_display, y_display-10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                    
                    # Mostrar la imagen con caras detectadas
                    cv2.imshow("Imagen Cargada - Caras Detectadas", image_display)
                    cv2.waitKey(1)  # Actualizar ventana
                    
                    # Preguntar si quiere agregar nombres a las caras nuevas
                    for i, (x, y, w, h) in enumerate(faces_nueva):
                        cara_nueva = image[y:y+h, x:x+w]
                        caracteristicas_nueva = extraer_caracteristicas(cara_nueva)
                        
                        if caracteristicas_nueva is not None:
                            # Verificar si es una cara conocida
                            es_conocida = False
                            if known_face_features:
                                for caracteristicas_conocidas in enumerate(known_face_features):
                                    similitud = comparar_caras(caracteristicas_nueva, caracteristicas_conocidas[1])
                                    if similitud > 0.6:
                                        es_conocida = True
                                        break
                            
                            if not es_conocida:
                                # Verificar si hay candidatos similares
                                mejor_candidato = None
                                mejor_similitud = 0
                                indice_candidato = -1
                                
                                for j, caracteristicas_conocidas in enumerate(known_face_features):
                                    similitud = comparar_caras(caracteristicas_nueva, caracteristicas_conocidas)
                                    if similitud > mejor_similitud and similitud > 0.3:
                                        mejor_similitud = similitud
                                        mejor_candidato = known_face_names[j]
                                        indice_candidato = j
                                
                                # Mostrar la cara individual
                                cara_ampliada = cv2.resize(cara_nueva, (200, 200))
                                cv2.imshow(f"Cara {i+1} - ¿Quién es?", cara_ampliada)
                                cv2.waitKey(1)
                                
                                # Preguntar el nombre
                                root = Tk()
                                root.withdraw()
                                
                                if mejor_candidato and mejor_similitud > 0.4:
                                    # Preguntar si es el candidato similar
                                    respuesta = simpledialog.askstring("Confirmar Identidad", 
                                        f"Cara {i+1} detectada.\nHe encontrado similitud con '{mejor_candidato}' ({mejor_similitud:.2f})\n\n¿Es esta persona {mejor_candidato}?\n\nEscribe 'si' para confirmar, 'no' para indicar otro nombre, o deja vacío para omitir:")
                                    
                                    if respuesta and respuesta.lower() in ['si', 'sí', 's', 'yes', 'y']:
                                        # Confirmar como persona existente
                                        known_face_features[indice_candidato] = (known_face_features[indice_candidato] + caracteristicas_nueva) / 2
                                        print(f"✅ {mejor_candidato} confirmado y características actualizadas")
                                        
                                        # Guardar la cara individual
                                        timestamp = int(time.time())
                                        file_path = os.path.join(UNKNOWN_FACES_DIR, f"{mejor_candidato}_{timestamp}.jpg")
                                        cv2.imwrite(file_path, cara_nueva)
                                        print(f"💾 Cara guardada como: {file_path}")
                                    elif respuesta and respuesta.lower() not in ['no', 'n']:
                                        # Nuevo nombre proporcionado
                                        nombre_final = respuesta.strip()
                                        if nombre_final.lower() not in [n.lower() for n in known_face_names]:
                                            known_face_features.append(caracteristicas_nueva)
                                            known_face_names.append(nombre_final)
                                            
                                            # Guardar la cara individual
                                            timestamp = int(time.time())
                                            file_path = os.path.join(UNKNOWN_FACES_DIR, f"{nombre_final}_{timestamp}.jpg")
                                            cv2.imwrite(file_path, cara_nueva)
                                            print(f"✅ {nombre_final} agregado a la base de datos")
                                            print(f"💾 Cara guardada como: {file_path}")
                                        else:
                                            print(f"⚠️ {nombre_final} ya existe. Actualizando características.")
                                            indice_existente = [n.lower() for n in known_face_names].index(nombre_final.lower())
                                            known_face_features[indice_existente] = (known_face_features[indice_existente] + caracteristicas_nueva) / 2
                                    elif respuesta and respuesta.lower() in ['no', 'n']:
                                        # Usuario dijo que NO es el candidato, pedir nuevo nombre
                                        nuevo_nombre = simpledialog.askstring("Nueva Persona", 
                                            f"Esta persona NO es {mejor_candidato}.\n¿Cuál es el nombre correcto?")
                                        if nuevo_nombre and nuevo_nombre.strip():
                                            nombre_final = nuevo_nombre.strip()
                                            if nombre_final.lower() not in [n.lower() for n in known_face_names]:
                                                known_face_features.append(caracteristicas_nueva)
                                                known_face_names.append(nombre_final)
                                                
                                                # Guardar la cara individual
                                                timestamp = int(time.time())
                                                file_path = os.path.join(UNKNOWN_FACES_DIR, f"{nombre_final}_{timestamp}.jpg")
                                                cv2.imwrite(file_path, cara_nueva)
                                                print(f"✅ {nombre_final} agregado a la base de datos")
                                                print(f"💾 Cara guardada como: {file_path}")
                                            else:
                                                print(f"⚠️ {nombre_final} ya existe. Actualizando características.")
                                                indice_existente = [n.lower() for n in known_face_names].index(nombre_final.lower())
                                                known_face_features[indice_existente] = (known_face_features[indice_existente] + caracteristicas_nueva) / 2
                                        else:
                                            print(f"⏭️ Cara {i+1} omitida")
                                    else:
                                        print(f"⏭️ Cara {i+1} omitida")
                                else:
                                    # No hay candidatos similares, persona completamente nueva
                                    nuevo_nombre = simpledialog.askstring("Nueva Persona", 
                                        f"Cara {i+1} detectada.\n¿Cuál es el nombre de esta persona?\n(Deja vacío para omitir)")
                                    
                                    if nuevo_nombre and nuevo_nombre.strip():
                                        nombre_final = nuevo_nombre.strip()
                                        if nombre_final.lower() not in [n.lower() for n in known_face_names]:
                                            known_face_features.append(caracteristicas_nueva)
                                            known_face_names.append(nombre_final)
                                            
                                            # Guardar la cara individual
                                            timestamp = int(time.time())
                                            file_path = os.path.join(UNKNOWN_FACES_DIR, f"{nombre_final}_{timestamp}.jpg")
                                            cv2.imwrite(file_path, cara_nueva)
                                            print(f"✅ {nombre_final} agregado a la base de datos")
                                            print(f"💾 Cara guardada como: {file_path}")
                                        else:
                                            print(f"⚠️ {nombre_final} ya existe. Actualizando características.")
                                            indice_existente = [n.lower() for n in known_face_names].index(nombre_final.lower())
                                            known_face_features[indice_existente] = (known_face_features[indice_existente] + caracteristicas_nueva) / 2
                                    else:
                                        print(f"⏭️ Cara {i+1} omitida")
                                
                                # Cerrar ventana de la cara individual
                                cv2.destroyWindow(f"Cara {i+1} - ¿Quién es?")
                    
                    # Guardar cambios
                    if len(known_face_features) > 0:
                        guardar_caracteristicas()
                        print(f"💾 Base de datos actualizada. Total: {len(known_face_names)} personas")
                    
                    # Mantener la ventana de imagen abierta un poco más
                    print("👁️ Imagen mostrada. Presiona cualquier tecla en la ventana de imagen para continuar...")
                    cv2.waitKey(0)  # Esperar hasta que se presione una tecla
                    cv2.destroyWindow("Imagen Cargada - Caras Detectadas")
                    
                else:
                    print("❌ No se detectaron caras en la imagen.")
                    # Mostrar la imagen sin caras detectadas
                    cv2.imshow("Imagen Cargada - Sin Caras", image_display)
                    print("👁️ Imagen mostrada sin caras detectadas. Presiona cualquier tecla para continuar...")
                    cv2.waitKey(0)
                    cv2.destroyWindow("Imagen Cargada - Sin Caras")
            else:
                print("❌ Error al cargar la imagen.")
        else:
            print("⏭️ No se seleccionó ninguna imagen.")
    
    # Presionar 's' para guardar características
    elif key == ord('s'):
        guardar_caracteristicas()
    
    # Presionar 'v' para ver imágenes de una persona
    elif key == ord('v'):
        ver_imagenes_persona()
    
    # Presionar 'r' para corregir reconocimiento
    elif key == ord('r'):
        if modo_correccion:
            # Confirmar corrección
            corregir_reconocimiento()
        else:
            # Activar modo corrección - necesita seleccionar una cara
            if len(faces) > 0:
                # Por simplicidad, usamos la primera cara detectada
                x, y, w, h = faces[0]
                cara_detectada = frame[y:y+h, x:x+w]
                caracteristicas = extraer_caracteristicas(cara_detectada)
                if caracteristicas is not None:
                    iniciar_modo_correccion(cara_detectada, caracteristicas, (x, y, w, h))
                else:
                    print("No se pudieron extraer características de la cara.")
            else:
                print("No hay caras detectadas para corregir.")
    
    # Presionar 'x' para cancelar corrección
    elif key == ord('x'):
        if modo_correccion:
            cancelar_correccion()
        else:
            print("No hay corrección activa para cancelar.")
    
    # Presionar 'i' para mostrar información
    elif key == ord('i'):
        mostrar_estadisticas()
    
    # Presionar 'q' para salir
    elif key == ord('q'):
        break

# Liberar recursos
if usar_camara and video_capture.isOpened():
    video_capture.release()
cv2.destroyAllWindows()
print("Programa finalizado.")
