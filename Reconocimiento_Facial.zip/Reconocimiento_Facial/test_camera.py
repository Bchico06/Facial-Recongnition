import cv2

print("Probando acceso a la cámara...")

# Intentar inicializar la cámara
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("No se pudo abrir la cámara con índice 0")
    # Probar otros índices
    for i in range(1, 5):
        print(f"Probando índice {i}...")
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            print(f"Cámara encontrada en índice {i}")
            break
        cap.release()

if not cap.isOpened():
    print("No se encontró ninguna cámara disponible")
    exit(1)

print("Cámara inicializada. Presiona 'q' para salir.")

while True:
    ret, frame = cap.read()
    
    if not ret:
        print("No se pudo leer frame")
        break
    
    cv2.imshow('Test Camera', frame)
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
print("Test finalizado.")
