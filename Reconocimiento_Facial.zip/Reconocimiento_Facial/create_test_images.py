import cv2
import numpy as np

# Crear una imagen de prueba con una cara simple
img = np.zeros((400, 400, 3), dtype=np.uint8)
img.fill(255)  # Fondo blanco

# Dibujar una cara simple
cv2.circle(img, (200, 200), 100, (200, 200, 200), -1)  # Cara
cv2.circle(img, (170, 170), 10, (0, 0, 0), -1)  # Ojo izquierdo
cv2.circle(img, (230, 170), 10, (0, 0, 0), -1)  # Ojo derecho
cv2.ellipse(img, (200, 220), (30, 15), 0, 0, 180, (0, 0, 0), 2)  # Sonrisa

# Guardar la imagen
cv2.imwrite('baby_faces/test_baby.jpg', img)
print("Imagen de prueba creada en baby_faces/test_baby.jpg")

# También crear una imagen más realista usando ruido
img2 = np.random.randint(0, 255, (300, 300, 3), dtype=np.uint8)
cv2.imwrite('baby_faces/test_baby2.jpg', img2)
print("Segunda imagen de prueba creada")
