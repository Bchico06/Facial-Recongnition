# Configuración de Python y pip

## Para hacer que pip funcione sin `py -m`:

1. **Reinicia VS Code** para que tome los cambios del PATH que ya hicimos.

2. **Verifica que funcionó** abriendo una nueva terminal y ejecutando:
   ```powershell
   pip --version
   python --version
   ```

3. **Si aún no funciona**, agrega manualmente Python al PATH:
   - Presiona Win + R, escribe `sysdm.cpl` y presiona Enter
   - Ve a la pestaña "Opciones avanzadas"
   - Haz clic en "Variables de entorno"
   - En "Variables del usuario", selecciona "Path" y haz clic en "Editar"
   - Agrega estas dos rutas:
     - `C:\Users\Bautaa\AppData\Local\Programs\Python\Python313`
     - `C:\Users\Bautaa\AppData\Local\Programs\Python\Python313\Scripts`

## Para face_recognition:

El paquete `face_recognition` requiere compilación y puede tener problemas con Python 3.13.
Opciones:

1. **Usar una versión precompilada** (recomendado):
   ```powershell
   pip install face-recognition-models
   pip install https://github.com/ageitgey/face_recognition/archive/master.zip
   ```

2. **Instalar Visual Studio Build Tools** para compilar:
   - Descarga Visual Studio Build Tools
   - Instala con componentes de C++
   - Luego ejecuta: `pip install face_recognition`

3. **Usar una alternativa más simple** como OpenCV con Haar Cascades o MediaPipe.
