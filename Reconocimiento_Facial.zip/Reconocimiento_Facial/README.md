# Sistema de Reconocimiento Facial con OpenCV

Este proyecto implementa un sistema de reconocimiento facial usando OpenCV en lugar de face_recognition, que es más compatible y fácil de instalar.

## Características

- ✅ **Detección facial** usando clasificadores Haar de OpenCV
- ✅ **Reconocimiento facial** usando comparación de histogramas HSV
- ✅ **Interfaz interactiva** para agregar nuevas caras
- ✅ **Almacenamiento persistente** de características faciales
- ✅ **Funciona con Python 3.13** sin problemas de compilación

## Requisitos

Los siguientes paquetes ya están instalados:
- opencv-python
- numpy
- tkinter (incluido con Python)

## Estructura del proyecto

```
Reconocimiento_Facial/
├── main.py                 # Programa principal
├── baby_faces/            # Carpeta para imágenes conocidas
├── unknown_faces/         # Carpeta para nuevas caras guardadas
├── face_features.pkl      # Archivo de características guardadas
└── README.md             # Este archivo
```

## Cómo usar

### 1. Ejecutar el programa

```bash
python main.py
```

### 2. Controles del programa

- **'q'** - Salir del programa
- **'c'** - Cargar una nueva imagen desde archivo
- **'s'** - Guardar características manualmente

### 3. Reconocimiento automático

- El programa detecta caras automáticamente
- Si reconoce una cara, muestra el nombre y nivel de confianza
- Si no reconoce una cara, pregunta el nombre y la guarda

### 4. Agregar caras conocidas

**Opción 1: Colocar imágenes en la carpeta**
1. Coloca imágenes JPG/PNG en la carpeta `baby_faces/`
2. Nombra los archivos con el nombre de la persona
3. El programa cargará automáticamente las caras al iniciar

**Opción 2: Usar la cámara**
1. Cuando aparezca una cara desconocida, ingresa el nombre
2. La cara se guardará automáticamente

**Opción 3: Cargar desde archivo**
1. Presiona 'c' durante la ejecución
2. Selecciona una imagen
3. Se agregará automáticamente

## Mejoras incluidas

1. **Sistema de confianza**: Muestra qué tan seguro está el reconocimiento
2. **Almacenamiento eficiente**: Guarda características en lugar de imágenes
3. **Detección robusta**: Usa clasificadores Haar probados
4. **Interfaz visual**: Colores diferentes para caras conocidas/desconocidas

## Problemas comunes y soluciones

### Python no se encuentra
Si obtienes "Python no se encuentra", usa la ruta completa:
```bash
C:\Users\Bautaa\AppData\Local\Programs\Python\Python313\python.exe main.py
```

### No se detectan caras
- Asegúrate de tener buena iluminación
- La cara debe estar de frente
- Ajusta el parámetro `umbral_reconocimiento` en el código

### Reconocimiento impreciso
- Ajusta `umbral_reconocimiento` (línea ~105):
  - Valores más altos = más estricto
  - Valores más bajos = más permisivo
- Agrega más imágenes de la misma persona

## Comparación con face_recognition

| Característica | face_recognition | OpenCV (este proyecto) |
|----------------|------------------|------------------------|
| Instalación | Difícil (requiere compilación) | ✅ Fácil |
| Python 3.13 | ❌ Problemas de compatibilidad | ✅ Compatible |
| Precisión | Muy alta | Buena |
| Velocidad | Media | ✅ Rápida |
| Recursos | Alto uso de CPU | ✅ Ligero |

Este proyecto es ideal para comenzar con reconocimiento facial sin las complicaciones de instalación de dlib y face_recognition.
